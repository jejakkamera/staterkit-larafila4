@blaze

<template name="summary">
    <div {{ $attributes }}>
        {{ $slot }}
    </div>
</template>
