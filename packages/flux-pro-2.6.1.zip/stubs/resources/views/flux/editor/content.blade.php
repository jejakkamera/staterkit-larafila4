@blaze

<ui-editor-content {{ $attributes }} wire:ignore>{{ $slot }}</ui-editor-content>
